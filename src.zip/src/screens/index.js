export {MapScreen} from './map';
// export {ComponentScreen} from './componentScreen';
export {News} from './news';
// export {Man} from './man';
export {Woman} from './Woman';
export {HomeScreen} from './home';
export {default as Profile} from './profile/Profile';
export {default as OnBoardingScreen} from './onBoardingScreen/OnBoardingScreen';
export {default as LoadingScreen} from './loadingScreen/LoadingScreen';
