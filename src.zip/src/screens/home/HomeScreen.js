import React, {useState, useEffect} from 'react';
import {Text, View, ScrollView} from 'react-native';
import {SvgUri} from 'react-native-svg';

import Skeleton from '../../components/Skeleton';
import Pagination from '../../components/Pagination';

import {Decrease, Increase} from '../../assets/Images/index';

import {Color} from '../../assets/themes/Color';

import {styles} from './HomeScreen-styles';

const HomeScreen = () => {
  const [data, setdata] = useState([]);
  const [loading, setloading] = useState(true);
  const [showPerPage, setshowPerPage] = useState(5);

  const [pagination, setpagination] = useState({
    start: 0,
    end: showPerPage,
  });

  const onpageChange = (start, end) => {
    setpagination({
      start: start,
      end: end,
    });
  };

  const URL = `https://6242c48cd126926d0c56bb9f.mockapi.io/covid19`;

  useEffect(() => {
    const getData = async () => {
      try {
        const response = await fetch(URL);
        const parsedResponse = await response.json();
        setdata(parsedResponse);
        // console.log(parsedResponse);
      } catch (error) {
        console.error(error);
      } finally {
        setloading(false);
      }
    };
    getData();
  }, []);

  return (
    <ScrollView
      style={{flex: 1, padding: 10, backgroundColor: Color.white}}
      bounces={false}>
      <View
        style={{
          width: '100%',
          height: '100%',
          borderWidth: 2,
          borderColor: Color.lightgray,
          borderRadius: 10,
        }}>
        <View
          style={{
            backgroundColor: Color.white,
            paddingLeft: 10,
            paddingRight: 10,
            marginTop: 10,
            justifyContent: 'space-between',
            flexDirection: 'row',
          }}>
          <Text
            style={{color: Color.ReportText, fontSize: 17, fontWeight: 'bold'}}>
            Live Reports
          </Text>
          <Pagination page={showPerPage} onpageChange={onpageChange} />
        </View>
        <Text
          style={{
            backgroundColor: Color.white,
            color: Color.Grey,
            paddingLeft: 10,
          }}>
          Top five countries
        </Text>

        {loading ? (
          <Skeleton itemCount={5} />
        ) : (
          data?.slice(pagination.start, pagination.end).map(item => (
            <View
              key={`${item.id} ${item.country}`}
              style={styles.cardContainer}>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  height: 100,
                }}>
                <View style={styles.imageContainer}>
                  <SvgUri
                    uri={item.countryFlag}
                    style={styles.countryFlag}
                    resizeMode="cover"
                  />
                </View>

                <Text style={styles.countryText}>{item.country}</Text>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  height: 100,
                  width: 'auto',
                  marginRight: 10,
                }}>
                <Text style={styles.affectedText}>
                  {item?.affected.toLocaleString()}
                </Text>
                {item?.affected > 40000000 ? (
                  <Decrease style={styles.Chevron} />
                ) : (
                  <Increase style={styles.Chevron} />
                )}
              </View>
            </View>
          ))
        )}
      </View>
    </ScrollView>
  );
};

export default HomeScreen;
