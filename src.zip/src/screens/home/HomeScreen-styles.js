import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  cardContainer: {
    width: '95%',
    height: 100,
    backgroundColor: '#ECECEC ',
    borderWidth: 2,
    borderColor: 'rgba(228, 228, 228, 0.6)',
    borderRadius: 10,
    margin: 10,
    marginBottom: 5,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  imageContainer: {
    borderRadius: 10,
    overflow: 'hidden',
    borderWidth: 1,
    margin: 10,
    borderColor: 'white',
  },
  countryFlag: {
    width: 50,
    height: 40,
  },

  countryText: {
    fontSize: 22,
  },
  affectedText: {
    fontSize: 17,
    fontWeight: 'bold',
    marginRight: 10,
    width: 'auto',
  },
  Chevron: {
    marginRight: 10,
  },
});
