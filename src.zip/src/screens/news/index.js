export {default as News} from './News';
