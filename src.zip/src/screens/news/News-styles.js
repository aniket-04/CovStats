import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  kids: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
