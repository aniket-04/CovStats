import React, {useState} from 'react';
import {SafeAreaView, ActivityIndicator, View} from 'react-native';
import {WebView} from 'react-native-webview';

const News = () => {
  const [isvisible, setVisibile] = useState(null);
  return (
    <SafeAreaView style={{flex: 1}}>
      <WebView
        source={{
          uri: 'https://www.cdc.gov/coronavirus/2019-ncov/your-health/index.html',
        }}
        //Enable JavaScript Support
        javaScriptEnabled={true}
        onLoadStart={() => setVisibile(true)}
        onLoad={() => setVisibile(false)}
      />
    </SafeAreaView>
  );
};

export default News;
