import React from 'react';
import {SafeAreaView} from 'react-native';
import {WebView} from 'react-native-webview';

import {styles} from './Man-styles';

const Man = () => {
  return (
    <SafeAreaView style={styles.man}>
      <WebView
        source={{
          uri: 'https://www.nbcnews.com/health/coronavirus',
        }}
      />
    </SafeAreaView>
  );
};

export default Man;
