export {default as Man} from './Man';
