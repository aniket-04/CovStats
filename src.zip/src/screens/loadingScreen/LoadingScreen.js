import React from 'react';
import {Text, View, SafeAreaView, Animated, Easing} from 'react-native';

import {styles} from './LoadingScreen-styles';

const LoadingScreen = () => {
  let rotateValue = new Animated.Value(0);

  (function rotate() {
    rotateValue.setValue(0);
    Animated.timing(rotateValue, {
      toValue: 1,
      alignItems: 'center',
      duration: 4000,
      easing: Easing.linear,
      useNativeDriver: false,
    }).start(() => rotate());
  })();

  const RotateData = rotateValue.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '520deg'],
  });

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.LogoContainer}>
        <Animated.Image
          source={require('../../assets/Images/Covid.jpg')}
          style={[styles.covidimage, {transform: [{rotate: RotateData}]}]}
        />
        <Text style={styles.text}>COVSTATS</Text>
      </View>
      <View style={styles.copyrightContainer}>
        <Text style={styles.copyrightText}>
          © Copyright COVSTATS 2022. All rights reserved
        </Text>
      </View>
    </SafeAreaView>
  );
};

export default LoadingScreen;
