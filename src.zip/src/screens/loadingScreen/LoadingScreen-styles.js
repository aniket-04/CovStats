import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    justifyContent: 'space-around',
    alignItems: 'center',
    height: '100%',
  },
  LogoContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
    height: '70%',
    width: '100%',
  },
  text: {
    fontWeight: '600',
    fontSize: 28,
    lineHeight: 34,
    color: '#FF647C',
    marginTop: 50,
  },
  copyrightContainer: {
    width: '100%',
    alignItems: 'center',
  },
  copyrightText: {
    fontWeight: '300',
    fontSize: 14,
    lineHeight: 17,
    textAlign: 'center',
  },
});
