import {StyleSheet, Text, SafeAreaView} from 'react-native';
import React from 'react';

import {WebView} from 'react-native-webview';

const Woman = () => {
  return (
    <SafeAreaView style={{flex: 1}}>
      <WebView
        source={{
          uri: 'https://www.google.co.in/maps/@28.6916608,77.185024,12z',
        }}
        javaScriptEnabled={true}
      />
    </SafeAreaView>
  );
};
export default Woman;

const styles = StyleSheet.create({});
