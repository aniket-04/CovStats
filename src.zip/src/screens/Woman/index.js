export {default as Woman} from './Woman';
