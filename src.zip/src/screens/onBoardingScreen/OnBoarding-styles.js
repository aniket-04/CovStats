import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  imageStyles: {
    shadowColor: 'rgba(50, 50, 71, 0.1)',
    // shadowColor: 'green',
    shadowRadius: 5,
    shadowOpacity: 11,
    shadowOffset: {width: 1, height: 15},
    elevation: 2,
    // backgroundColor: 'red',
    borderRadius: 200,
    BorderWidth: 20,
    shadowRadius: 1,
  },
  dot: {
    color: 'red',
  },
});
