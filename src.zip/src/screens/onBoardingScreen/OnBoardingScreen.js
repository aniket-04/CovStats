import React from 'react';
import {Text, View, TouchableOpacity, SafeAreaView, Button} from 'react-native';
import Onboarding from 'react-native-onboarding-swiper';

import {Cough, Fever, Breath} from '../../assets/Images';

import {styles} from './OnBoarding-styles';

//Dot custom
const dots = ({isLight, selected}) => {
  let backgroundColor;
  if (isLight) {
    backgroundColor = selected
      ? 'rgba(255,100,124, 0.8)'
      : 'rgba(0, 0, 0, 0.3)';
  } else {
    backgroundColor = selected ? '#000' : 'rgba(255, 255, 255, 0.5)';
  }
  return (
    <View
      style={{
        width: 8,
        height: 8,
        marginHorizontal: 3,
        backgroundColor,
        borderRadius: 50,
      }}
    />
  );
};

const backgroundColor = isLight => (isLight ? 'blue' : 'lightblue');
const colorr = isLight => backgroundColor(!isLight);

const Done = ({isLight, skipLabel, ...props}) => (
  <TouchableOpacity
    containerViewStyle={{
      marginVertical: 10,
      width: 70,
    }}
    textStyle={{color: colorr(isLight)}}
    {...props}>
    <Text style={{marginRight: 15, fontSize: 16, fontWeight: '500'}}>Done</Text>
    {skipLabel}
  </TouchableOpacity>
);

const OnBoardingScreen = ({navigation}) => {
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: 'white'}}>
      <Onboarding
        onDone={() => navigation.navigate('DrawerNavigation')}
        // SkipButtonComponent={Skip}
        DoneButtonComponent={Done}
        // skipToPage={2}
        bottomBarHeight={50}
        bottomBarColor="rgba(255, 255, 255, 1)"
        DotComponent={dots}
        subTitleStyles={{
          color: '#999',
          textAlign: 'center',
          fontSize: 16,
          alignSelf: 'center',
          maxWidth: '95%',
        }}
        pages={[
          {
            backgroundColor: '#FFF',
            image: <Fever style={styles.imageStyles} />,
            title: 'Fever',
            subtitle: `He severity of COVID-19 symptoms can range from very mild to severe. 
            Some people have no symptoms. People who are older or have existing chronic medical conditions.`,
          },
          {
            backgroundColor: '#fff',
            image: <Cough style={styles.imageStyles} />,
            title: 'Cough',
            subtitle: `Such as heart or lung disease or diabetis, may be at higher risk of serious illness. 
            This is similar to what is seen with other respiratory illnesses, such influenza.`,
          },
          {
            backgroundColor: '#fff',
            image: <Breath style={styles.imageStyles} />,
            title: 'Breathing Difficulty',
            subtitle:
              'Contact your doctor or clinic right away if you have COVID-19 symptoms, you’ve been exposed to someone with COVID-19, or you live in or have traveled from an area with ongoing community spread of COVID-19.',
          },
        ]}
      />
    </SafeAreaView>
  );
};

export default OnBoardingScreen;
