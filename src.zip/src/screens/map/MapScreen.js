import React, {useState, useEffect, useCallback} from 'react';
import {Text, ScrollView, View} from 'react-native';
import CircularProgress from 'react-native-circular-progress-indicator';

import Skeleton from '../../components/Skeleton';
import Location from '../../components/location/Location';

import {Bell, RBell} from '../../assets/Images';
import {Color} from '../../assets/themes/Color';

import {styles} from './MapScreen-styles';

const Settings = () => {
  const [data, setdata] = useState([]);
  const [loading, setloading] = useState(true);

  const [click, setclick] = useState([]);

  const colors = [Color.DarkPink, Color.AquaGreen, Color.Purple];
  // const progressValues = [26, 17, 9];

  const abc = useCallback(index => {
    console.log(click);
    console.log([
      ...click.slice(0, index - 1),
      !click[index - 1],
      ...click.slice(index),
    ]);

    if (index == data[index - 1].id) {
      setclick([
        ...click.slice(0, index - 1),
        !click[index - 1],
        ...click.slice(index),
      ]);
    }
  });

  const URL = 'https://6242c48cd126926d0c56bb9f.mockapi.io/covid19';

  //const URL = `https://corona-virus-stats.herokuapp.com/api/v1/cases/countries-search?limit=200`;

  useEffect(() => {
    fetch(URL)
      .then(response => response.json())
      .then(json => {
        setdata(json);
        setclick(new Array(json.length).fill(true));
      })
      .catch(error => console.error(error))
      .finally(() => setloading(!loading));
  }, []);
  console.log(data);

  const ProgressColor = useCallback(() => {
    return (
      '#' +
      Math.floor(Math.random() * 16777215)
        .toString(16)
        .padStart(6, '0')
        .toUpperCase()
    );
  });

  return (
    <ScrollView style={styles.mainContainer} bounces={false}>
      <View style={styles.mapContainer}>
        <Text style={styles.textContainer}>COVID - 19 Affected Areas</Text>
        <View style={styles.subTextContainer}>
          <Text style={styles.subText}>🟥 Most Affected</Text>
          <Text>🟧 Less Affected</Text>
        </View>
        <View style={styles.map}>
          <Location />
        </View>
      </View>

      <View style={styles.countriesContainer}>
        <View style={styles.countriesSubContainer}>
          <Text style={styles.topCountriesText}>Top Countries</Text>
        </View>

        {loading ? (
          <Skeleton itemCount={3} />
        ) : (
          data
            .sort((a, b) => b.affected - a.affected)
            .slice(0, 3)
            .map((item, idx) => (
              <View
                style={styles.cardContainer}
                key={`${item.id} ${item.country}`}>
                <View style={styles.cards}>
                  <View style={styles.cardsInner}>
                    <View style={styles.circleBox}>
                      <View style={styles.progressBox}>
                        <CircularProgress
                          value={(item?.recovered / item?.affected) * 100}
                          radius={47}
                          inActiveStrokeColor={Color.primary}
                          inActiveStrokeOpacity={0.2}
                          activeStrokeColor={colors[idx]}
                          progressValueColor={Color.black}
                          valueSuffix={'%'}
                        />
                      </View>
                    </View>

                    <View style={{flexDirection: 'column'}}>
                      <Text style={styles.countryName}>{item.country}</Text>
                      <Text style={styles.Affected}>
                        Affected-
                        {(
                          Math.sign(item?.affected) *
                          (Math.abs(item?.affected) / 1000).toFixed(1)
                        ).toLocaleString('en-US') + 'k'}
                      </Text>
                      <Text style={styles.Recovered}>
                        Recovered-
                        {(
                          Math.sign(item?.recovered) *
                          (Math.abs(item?.recovered) / 1000).toFixed(1)
                        ).toLocaleString('en-US') + 'k'}
                      </Text>
                    </View>
                  </View>
                  {click[idx] ? (
                    <RBell style={styles.Bell} onPress={() => abc(item.id)} />
                  ) : (
                    <Bell style={styles.Bell} onPress={() => abc(item.id)} />
                  )}
                </View>
              </View>
            ))
        )}
      </View>
    </ScrollView>
  );
};

export default Settings;
