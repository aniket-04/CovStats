import React, {useState} from 'react';
import {SafeAreaView, View, TouchableOpacity, Text, Alert} from 'react-native';

import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {useNavigation} from '@react-navigation/core';

import {HomeScreen, News, Woman, Man, MapScreen} from '../screens';
import {TabHome2, Map, Education, Discover, NewsIco} from '../assets/icons';
import {Hamburger, User} from '../assets/Images';

import {Color} from '../assets/themes/Color';
import {styles} from './TabNavigation-styles';

const Tab = createBottomTabNavigator();

const {Pink, Grey} = Color;

const TabRoutes = props => {
  const navigation = useNavigation();
  console.log(props);

  const [isPressed, setPressed] = useState(false);

  const userFun = () => {
    !isPressed && Alert.alert(`Status : Vaccinated ✅`);
    setPressed(!isPressed);
  };

  return (
    <Tab.Navigator
      initialRouteName={props.route.params.dfd}
      screenOptions={{
        headerShown: true,
        tabBarActiveTintColor: Pink,
        tabBarInactiveTintColor: Grey,
      }}>
      <Tab.Screen
        name="Covid-19"
        component={HomeScreen}
        options={{
          tabBarIcon: ({focused}) => <TabHome2 color={focused ? Pink : Grey} />,
          tabBarLabel: 'Home',

          header: ({navigation}) => (
            <>
              <SafeAreaView style={{backgroundColor: 'white'}} />
              <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.openDrawer()}>
                  <Hamburger style={{marginLeft: 10}} />
                </TouchableOpacity>
                <Text style={{fontSize: 18}}>Covid-19</Text>

                <TouchableOpacity style={{marginRight: 10}} onPress={userFun}>
                  <User color={isPressed && '#00C48C'} />
                </TouchableOpacity>
              </View>
            </>
          ),
        }}
      />
      <Tab.Screen
        name="Map"
        component={MapScreen}
        title={props.route.params.dfd}
        options={{
          tabBarIcon: ({focused}) => <Map color={focused ? Pink : Grey} />,
          tabBarLabel: 'Map',

          header: ({navigation}) => (
            <>
              <SafeAreaView style={{backgroundColor: 'white'}} />
              <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.openDrawer()}>
                  <Hamburger style={{marginLeft: 10}} />
                </TouchableOpacity>
                <Text style={{fontSize: 18}}>World Wide map</Text>

                <TouchableOpacity style={{marginRight: 10}} onPress={userFun}>
                  <User color={isPressed && '#00C48C'} />
                </TouchableOpacity>
              </View>
            </>
          ),
        }}
      />
      <Tab.Screen
        name="Education"
        component={News}
        title={props.route.params.dfd}
        options={{
          tabBarIcon: ({focused}) => (
            <Education color={focused ? Pink : Grey} />
          ),
          header: ({navigation}) => (
            <>
              <SafeAreaView style={{backgroundColor: 'white'}} />
              <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.openDrawer()}>
                  <Hamburger style={{marginLeft: 10}} />
                </TouchableOpacity>
                <Text style={{fontSize: 18}}>Education</Text>

                <TouchableOpacity style={{marginRight: 10}} onPress={userFun}>
                  <User color={isPressed && '#00C48C'} />
                </TouchableOpacity>
              </View>
            </>
          ),
        }}
      />
      <Tab.Screen
        name="Discovery"
        component={Woman}
        title={props.route.params.dfd}
        options={{
          tabBarIcon: ({focused}) => <Discover color={focused ? Pink : Grey} />,
          header: ({navigation}) => (
            <>
              <SafeAreaView style={{backgroundColor: 'white'}} />
              <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.openDrawer()}>
                  <Hamburger style={{marginLeft: 10}} />
                </TouchableOpacity>
                <Text style={{fontSize: 18}}>Discovery</Text>

                <TouchableOpacity style={{marginRight: 10}} onPress={userFun}>
                  <User color={isPressed && '#00C48C'} />
                </TouchableOpacity>
              </View>
            </>
          ),
        }}
      />

      <Tab.Screen
        name="News"
        component={News}
        title={props.route.params.dfd}
        options={{
          tabBarIcon: ({focused}) => <NewsIco color={focused ? Pink : Grey} />,
          header: ({navigation}) => (
            <>
              <SafeAreaView style={{backgroundColor: 'white'}} />
              <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.openDrawer()}>
                  <Hamburger style={{marginLeft: 10}} />
                </TouchableOpacity>
                <Text style={{fontSize: 18}}>News</Text>

                <TouchableOpacity style={{marginRight: 10}} onPress={userFun}>
                  <User color={isPressed && '#00C48C'} />
                </TouchableOpacity>
              </View>
            </>
          ),
        }}
      />
    </Tab.Navigator>
  );
};

export default TabRoutes;
