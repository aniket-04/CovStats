import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  header: {
    width: '100%',
    height: 50,
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    backgroundColor: 'white',
    flexDirection: 'row',
    borderBottomColor: 'rgba(228, 228, 228, 0.6)',
    borderBottomWidth: 4,
  },
});
