import React, {useEffect, useState} from 'react';

import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

import {OnBoardingScreen, LoadingScreen} from '../screens';
import DrawerNavigation from '../navigations/DrawerNavigation';
import navigationStrings from '../constants/navigationStrings';

const Stack = createNativeStackNavigator();

const StackNavigation = () => {
  const [isVisible, setVisibile] = useState(true);

  useEffect(() => {
    setTimeout(() => {
      setVisibile(false);
    }, 3000);
    return () => {};
  }, []);

  return (
    <NavigationContainer>
      <Stack.Navigator>
        {isVisible ? (
          <Stack.Screen
            options={{
              headerShown: false,
            }}
            name="LoadingScreen"
            component={LoadingScreen}
          />
        ) : null}

        <Stack.Screen
          options={{
            headerShown: false,
          }}
          name={navigationStrings.Onboarding}
          component={OnBoardingScreen}
        />
        <Stack.Screen
          options={{
            headerShown: false,
          }}
          name={navigationStrings.DrawerNavigation}
          component={DrawerNavigation}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default StackNavigation;
