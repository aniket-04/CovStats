import React from 'react';
//import OnBoardingScreen from '../screens/onBoardingScreen/OnBoardingScreen';

import DrawerNavigation from './DrawerNavigation';
import StackNavigation from './StackNavigation';

const Routes = () => {
  return <StackNavigation />;
  //<OnBoardingScreen />;

  // <DrawerNavigation />;
};

export default Routes;
