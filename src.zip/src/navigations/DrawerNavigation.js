import React from 'react';

import {createDrawerNavigator} from '@react-navigation/drawer';

import CustomerDrawer from '../components/customDrawer/CustomDrawer';

import {Color} from '../assets/themes/Color';
const {white, Grey, DarkPink, black} = Color;

import {DRAWER} from '../constants/DrawerConstants';

const Drawer = createDrawerNavigator();

const DrawerNavigation = () => {
  const dscreen = () => {
    return DRAWER.map((item, index) => {
      return (
        <Drawer.Screen
          initialParams={{
            dfd: item.name,
          }}
          options={{
            headerShown: item.headerShown,
            drawerIcon: ({focused}) => (
              <item.Icon color={focused ? white : Grey} />
            ),
          }}
          name={item.name}
          component={item.component}
          key={index}
        />
      );
    });
  };
  return (
    <Drawer.Navigator
      drawerContent={props => <CustomerDrawer {...props} />}
      // initialRouteName={navigationStrings.HomeScreen}
      screenOptions={{
        drawerActiveBackgroundColor: DarkPink,
        drawerActiveTintColor: white,
        drawerInactiveTintColor: black,
        drawerStyle: {width: 270},
        drawerLabelStyle: {fontFamily: 'Roboto-Regular', fontSize: 16},
      }}>
      {dscreen()}
    </Drawer.Navigator>
  );
};

export default DrawerNavigation;
