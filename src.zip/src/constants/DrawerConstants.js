import navigationStrings from './navigationStrings';
import {TabHome2, Map, Education, Discover, News} from '../assets/icons';

import TabRoutes from '../navigations/TabNavigation';

export const DRAWER = [
  {
    name: navigationStrings.HomeScreen,
    Icon: TabHome2,
    component: TabRoutes,
    headerShown: false,
    title: 'Covid-19',
  },
  {
    name: navigationStrings.Map,
    Icon: Map,
    component: TabRoutes,
    headerShown: false,
    title: 'World wide Map',
  },
  {
    name: navigationStrings.Education,
    Icon: Education,
    component: TabRoutes,
    headerShown: false,
    title: 'Education',
  },
  {
    name: navigationStrings.Discovery,
    Icon: Discover,
    component: TabRoutes,
    headerShown: false,
    title: 'Discovery',
  },
  {
    name: navigationStrings.News,
    Icon: News,
    component: TabRoutes,
    headerShown: false,
    title: 'News',
  },
];
