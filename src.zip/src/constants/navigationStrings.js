export default {
  HomeScreen: 'Home',
  Map: 'Map',
  Education: 'Education',
  Discovery: 'Discovery',
  News: 'News',
  Heroname: 'Rachel Brown',
  Onboarding: 'OnboardingScreen',
  DrawerNavigation: 'DrawerNavigation',
  LoadingScreen: 'LoadingScreen',
};
