import React, {useState, useEffect} from 'react';
import {TouchableOpacity, View, SafeAreaView, Alert} from 'react-native';

import {ArrowL, ArrowR} from '../assets/icons';

import {Color} from '../assets/themes/Color';

const Pagination = ({page, onpageChange}) => {
  //   console.log(page);

  const [counter, setCounter] = useState(0);

  const goBack = () => {
    setCounter(currentcounter =>
      currentcounter > 0 ? currentcounter - 5 : currentcounter,
    );
    console.log(counter);
  };
  const goAhead = () => {
    setCounter(currentcounter =>
      currentcounter < 40 ? currentcounter + 5 : currentcounter,
    );
    console.log(counter);
  };

  useEffect(() => {
    const value = page + counter;
    // console.log('start value', value - page);
    // console.log('end value', value);
    // console.log(page);
    // console.log('------');
    onpageChange(value - page, value);
  }, [counter]);

  return (
    <SafeAreaView>
      <View
        style={{
          alignSelf: 'center',
          flexDirection: 'row',
          borderWidth: 1,
          borderRadius: 7,
          borderColor: Color.lightgray,
          position: 'relative',
          marginRight: 10,
        }}>
        <TouchableOpacity
          style={{
            backgroundColor: 'white',
            width: 30,
            height: 35,
            borderTopLeftRadius: 7,
            borderLeftRadius: 7,
            borderBottomLeftRadius: 7,
            borderColor: Color.lightgray,
            alignItems: 'center',
            justifyContent: 'center',
          }}
          onPress={goBack}>
          <ArrowL width="25" height="25" />
        </TouchableOpacity>

        <TouchableOpacity
          style={{
            backgroundColor: 'white',
            width: 30,
            height: 35,
            borderTopRightRadius: 7,
            borderRightRadius: 7,
            borderColor: Color.Grey,
            borderBottomRightRadius: 7,
            alignItems: 'center',
            justifyContent: 'center',
          }}
          onPress={goAhead}>
          <ArrowR width="25" height="25" />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default Pagination;
