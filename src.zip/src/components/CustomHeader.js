import {
  View,
  Text,
  TouchableHighlight,
  SafeAreaView,
  Alert,
} from 'react-native';
import React from 'react';
import {Hamburger} from '../assets/Images';

const CustomHeader = ({title}) => {
  return (
    <SafeAreaView style={{flex: 1}}>
      <TouchableHighlight style={{}} onPress={() => Alert.alert('hello')}>
        <Hamburger onPress={() => Alert.alert('hello')} />
      </TouchableHighlight>
      <Text>anc</Text>
      <View></View>
    </SafeAreaView>
  );
};

export default CustomHeader;
