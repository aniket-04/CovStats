import {Text, View} from 'react-native';
import React, {useState} from 'react';
import MapView from 'react-native-maps';
import {Marker} from 'react-native-maps';

const Location = () => {
  const [coordinate, setCoordinate] = useState({
    latitude: 37.4215607,
    longitude: -122.0848566,
  });

  const regionChange = region => {
    setCoordinate(region);
  };

  return (
    <View>
      <MapView
        showsUserLocation={true}
        style={{height: '100%', width: '100%'}}
        initialRegion={{
          latitude: coordinate.latitude,
          longitude: coordinate.longitude,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421,
        }}
        onRegionChange={regionChange}>
        <Marker
          coordinate={{
            latitude: coordinate.latitude,
            longitude: coordinate.longitude,
          }}
        />
      </MapView>
    </View>
  );
};
export default Location;
