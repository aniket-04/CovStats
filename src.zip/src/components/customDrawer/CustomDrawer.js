import React from 'react';
import {Text, View, Image, Alert} from 'react-native';
import {
  DrawerContentScrollView,
  DrawerItemList,
} from '@react-navigation/drawer';
import navigationStrings from '../../constants/navigationStrings';

import {styles} from './CustomDrawer-styles';

const CustomDrawer = props => {
  const click = () => {
    Alert.alert('Already Signed In');
  };
  return (
    <View style={{flex: 1}}>
      <DrawerContentScrollView {...props}>
        <View style={styles.ProfileContainer}>
          <Image
            source={require('../../assets/Images/hero.jpg')}
            style={styles.heroImage}
            resizeMode="cover"
          />

          <Text style={styles.Username}>{navigationStrings.Heroname}</Text>
          <Text
            style={styles.UserDetail_text}
            onPress={() => Alert.alert('hello')}>
            Location
          </Text>
        </View>

        <DrawerItemList {...props} />
      </DrawerContentScrollView>
    </View>
  );
};

export default CustomDrawer;
