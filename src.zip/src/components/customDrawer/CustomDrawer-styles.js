import {StyleSheet} from 'react-native';
import {Color} from '../../assets/themes/Color';
export const styles = StyleSheet.create({
  heroImage: {
    borderRadius: 50,
    height: 50,
    width: 50,
    marginBottom: 10,
    marginTop: 70,
    marginLeft: 20,
  },
  Username: {
    fontFamily: 'Roboto-Medium',
    fontSize: 18,
    color: Color.white,
    marginLeft: 20,
  },
  SignOut: {
    paddingTop: 15,
    fontSize: 18,
  },
  SignIn: {
    fontSize: 18,
    paddingBottom: 5,
  },
  Ratings: {
    marginRight: 5,
    color: Color.DarkYellow,
  },
  Star: {
    marginLeft: 5,
  },
  ProfileContainer: {
    backgroundColor: Color.DarkPink,
    marginBottom: 10,
    paddingBottom: 20,
    marginTop: -60,
    height: 200,
  },
  UserDetail_Container: {
    flexDirection: 'row',
    marginLeft: 20,
    marginTop: 15,
  },
  UserDetail_member: {
    marginRight: 10,
    color: 'white',
    backgroundColor: Color.UserPink,
    paddingLeft: 2,
    paddingRight: 2,
    width: 30,
    borderRadius: 50,
  },
  UserDetail_text: {
    margin: 10,
    marginLeft: 20,
    fontSize: 20,
    fontWeight: '500',
    color: Color.black,
  },
  SignInContainer: {
    backgroundColor: Color.white,
    marginTop: 20,
  },
});
