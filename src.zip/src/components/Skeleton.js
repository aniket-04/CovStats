import React from 'react';
import {ScrollView, View} from 'react-native';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';

import {Color} from '../assets/themes/Color';

const Skeleton = ({itemCount}) => {
  return Array(itemCount).fill(
    React.Children.toArray(
      <ScrollView
        contentContainerStyle={{alignItems: 'center'}}
        bounces={false}>
        <View
          style={{
            marginTop: 10,
            marginBottom: 10,
            backgroundColor: Color.SkeletonBackground,
            alignItems: 'center',
            borderColor: Color.SkeletonBorder,
            borderRadius: 12,
            alignSelf: 'center',
          }}>
          <SkeletonPlaceholder
            backgroundColor={Color.SkeletonPlaceholder}
            speed={500}>
            <View
              style={{
                width: 350,
                height: 95,
                borderRadius: 10,
                alignSelf: 'center',
              }}
            />
          </SkeletonPlaceholder>
        </View>
      </ScrollView>,
    ),
  );
};

export default Skeleton;
